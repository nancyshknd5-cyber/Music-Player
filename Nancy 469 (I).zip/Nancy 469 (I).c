#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <conio.h>

#define RESET   "\033[0m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define CYAN    "\033[1;36m"
#define RED     "\033[1;31m"
#define BOLD    "\033[1m"

void songStartSound() {
    Beep(523, 150);   
    Beep(587, 150);  
    Beep(659, 150);  
    Beep(784, 300);   
}
void nextSound() {
    Beep(600, 100);
    Beep(900, 150);
}

void prevSound() {
    Beep(900, 100);
    Beep(600, 150);
}

void addSound() {
    Beep(800, 80);
    Beep(1000, 150);
}

void errorSound() {
    Beep(300, 400);
}
void exitSound() {
    Beep(784, 150);
    Beep(659, 150);
    Beep(523, 300);
}
struct Song {
    char title[100];
    int  playCount;
    struct Song *prev, *next;
};
struct Song *head = NULL, *current = NULL;

void addSong(char title[]) {
    struct Song *s = (struct Song*)malloc(sizeof(struct Song));
    strcpy(s->title, title);
    s->playCount = 0;
    s->prev = s->next = NULL;
    if (!head) { head = current = s; }
    else {
        struct Song *t = head;
        while (t->next) t = t->next;
        t->next = s; s->prev = t;
    }
    addSound();
    printf(GREEN "  [+] Added: %s\n" RESET, title);
}
void deleteSong(char title[]) {
    struct Song *t = head;
    while (t && strcmp(t->title, title) != 0) t = t->next;
    if (!t) { errorSound(); printf(RED "  Song not found!\n" RESET); return; }
    if (t == current) current = t->next ? t->next : t->prev;
    if (t->prev) t->prev->next = t->next;
    else head = t->next;
    if (t->next) t->next->prev = t->prev;
    free(t);
    printf(RED "  [-] Deleted: %s\n" RESET, title);
}
void displayPlaylist() {
    if (!head) { errorSound(); printf(RED "  Playlist empty!\n" RESET); return; }
    printf(YELLOW "\n  ====== Playlist ======\n" RESET);
    struct Song *t = head; int i = 1;
    while (t) {
        if (t == current)
            printf(GREEN "  %d. %-25s [Playing] Played: %dx\n" RESET, i, t->title, t->playCount);
        else
            printf("  %d. %-25s Played: %dx\n", i, t->title, t->playCount);
        t = t->next; i++;
    }
    printf(YELLOW "  ======================\n" RESET);
}
void visualizeList() {
    printf(CYAN "\n  Linked List Structure:\n  " RESET);
    struct Song *t = head;
    while (t) {
        if (t == current) printf(GREEN "[%s]" RESET, t->title);
        else printf("[%s]", t->title);
        if (t->next) printf(" <-> ");
        t = t->next;
    }
    printf("\n");
}
void searchSong(char title[]) {
    struct Song *t = head; int found = 0, i = 1;
    while (t) {
        if (strstr(t->title, title)) {
            printf(GREEN "  Found at position %d: %s\n" RESET, i, t->title);
            found = 1;
        }
        t = t->next; i++;
    }
    if (!found) { errorSound(); printf(RED "  No song found.\n" RESET); }
}
void mostPlayed() {
    if (!head) return;
    struct Song *t = head, *best = head;
    while (t) { if (t->playCount > best->playCount) best = t; t = t->next; }
    printf(CYAN "  Most Played: %s (%dx)\n" RESET, best->title, best->playCount);
}
struct SNode { char title[100]; struct SNode *next; };
struct SNode *top = NULL;

void push(char title[]) {
    struct SNode *s = (struct SNode*)malloc(sizeof(struct SNode));
    strcpy(s->title, title); s->next = top; top = s;
}
char* pop() {
    if (!top) return NULL;
    static char t[100]; strcpy(t, top->title);
    struct SNode *tmp = top; top = top->next; free(tmp);
    return t;
}
struct QNode { char title[100]; struct QNode *next; };
struct QNode *qFront = NULL, *qRear = NULL;

void enqueue(char title[]) {
    struct QNode *q = (struct QNode*)malloc(sizeof(struct QNode));
    strcpy(q->title, title); q->next = NULL;
    if (!qRear) { qFront = qRear = q; }
    else { qRear->next = q; qRear = q; }
    addSound();
    printf(GREEN "  [Q] Queued: %s\n" RESET, title);
}
void dequeue() {
    if (!qFront) { errorSound(); printf(RED "  Queue empty!\n" RESET); return; }
    printf(GREEN "  >> Playing from Queue: %s\n" RESET, qFront->title);
    songStartSound();
    struct QNode *tmp = qFront; qFront = qFront->next;
    if (!qFront) qRear = NULL; free(tmp);
}
void playCurrent() {
    if (!current) { errorSound(); printf(RED "  No song selected!\n" RESET); return; }
    current->playCount++;
    printf(GREEN "\n  >> Now Playing: %s\n" RESET, current->title);
    songStartSound();
    visualizeList();
}
void nextSong() {
    if (!current || !current->next) { errorSound(); printf(RED "  Last song!\n" RESET); return; }
    push(current->title); current = current->next;
    nextSound();
    playCurrent();
}
void prevSong() {
    char *t = pop();
    if (!t) { errorSound(); printf(RED "  No previous song!\n" RESET); return; }
    struct Song *tmp = head;
    while (tmp && strcmp(tmp->title, t) != 0) tmp = tmp->next;
    if (tmp) { current = tmp; prevSound(); playCurrent(); }
}
int main() {
    int choice; char name[100];
    printf(BOLD "\n+------------------------------+\n");
    printf("      Music Player Pro\n");
    printf("+------------------------------+\n" RESET);

    addSong("Kesariya");
    addSong("Believer");
    addSong("Tum Hi Ho");
    addSong("Shape of You");

    while (1) {
        printf(YELLOW "\n------- MENU -------\n" RESET);
        printf("1.Playlist   2.Play    3.Next   4.Previous\n");
        printf("5.Add Song   6.Delete  7.Search 8.Most Played\n");
        printf("9.Add Queue  10.Play Queue       11.Exit\n");
        printf(YELLOW "--------------------\n" RESET);
        printf(CYAN "Choice: " RESET);
        scanf("%d", &choice); getchar();

        if      (choice == 1)  displayPlaylist();
        else if (choice == 2)  playCurrent();
        else if (choice == 3)  nextSong();
        else if (choice == 4)  prevSong();
        else if (choice == 5)  { printf("Song name: "); fgets(name,100,stdin); name[strcspn(name,"\n")]=0; addSong(name); }
        else if (choice == 6)  { printf("Song to delete: "); fgets(name,100,stdin); name[strcspn(name,"\n")]=0; deleteSong(name); }
        else if (choice == 7)  { printf("Search: "); fgets(name,100,stdin); name[strcspn(name,"\n")]=0; searchSong(name); }
        else if (choice == 8)  mostPlayed();
        else if (choice == 9)  { printf("Song name: "); fgets(name,100,stdin); name[strcspn(name,"\n")]=0; enqueue(name); }
        else if (choice == 10) dequeue();
        else if (choice == 11) { exitSound(); printf(GREEN "\n  Goodbye!\n\n" RESET); break; }
        else { errorSound(); printf(RED "  Invalid!\n" RESET); }
    }
    return 0;
}
